-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: yz
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `userhzlvl`
--

DROP TABLE IF EXISTS `userhzlvl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userhzlvl` (
  `userid` varchar(45) NOT NULL,
  `zi` char(1) CHARACTER SET gb2312 NOT NULL,
  `level` int(11) NOT NULL,
  PRIMARY KEY (`userid`,`zi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userhzlvl`
--

LOCK TABLES `userhzlvl` WRITE;
/*!40000 ALTER TABLE `userhzlvl` DISABLE KEYS */;
INSERT INTO `userhzlvl` VALUES ('kyle','八',1),('kyle','二',1),('kyle','个',1),('kyle','九',1),('kyle','六',1),('kyle','么',1),('kyle','七',1),('kyle','三',1),('kyle','山',1),('kyle','上',1),('kyle','十',1),('kyle','什',1),('kyle','手',1),('kyle','四',1),('kyle','头',1),('kyle','为',1),('kyle','五',1),('kyle','一',1),('kyle','只',1),('zack','啊',1),('zack','哀',0),('zack','爱',2),('zack','安',1),('zack','吧',1),('zack','八',1),('zack','巴',2),('zack','把',2),('zack','爸',1),('zack','白',1),('zack','百',2),('zack','搬',0),('zack','板',0),('zack','半',1),('zack','包',2),('zack','宝',2),('zack','抱',2),('zack','北',2),('zack','背',2),('zack','倍',1),('zack','鼻',0),('zack','比',1),('zack','笔',0),('zack','边',2),('zack','变',0),('zack','别',1),('zack','丙',1),('zack','不',2),('zack','擦',0),('zack','才',1),('zack','菜',0),('zack','参',0),('zack','草',2),('zack','叉',0),('zack','茶',0),('zack','察',2),('zack','长',2),('zack','厂',1),('zack','唱',2),('zack','车',1),('zack','扯',0),('zack','橙',0),('zack','成',1),('zack','乘',0),('zack','吃',1),('zack','迟',2),('zack','齿',0),('zack','赤',0),('zack','冲',0),('zack','虫',0),('zack','出',1),('zack','橱',0),('zack','除',0),('zack','处',1),('zack','穿',1),('zack','船',0),('zack','床',0),('zack','吹',0),('zack','春',1),('zack','唇',0),('zack','次',1),('zack','葱',0),('zack','从',1),('zack','粗',0),('zack','醋',0),('zack','打',1),('zack','大',1),('zack','弹',0),('zack','当',2),('zack','到',2),('zack','稻',0),('zack','道',1),('zack','得',2),('zack','的',2),('zack','凳',0),('zack','低',0),('zack','地',1),('zack','弟',0),('zack','点',2),('zack','电',0),('zack','碟',0),('zack','东',2),('zack','冬',0),('zack','动',1),('zack','都',2),('zack','短',0),('zack','队',1),('zack','对',1),('zack','吨',1),('zack','多',2),('zack','朵',2),('zack','鹅',0),('zack','儿',2),('zack','耳',2),('zack','二',2),('zack','发',1),('zack','法',0),('zack','饭',0),('zack','方',1),('zack','仿',0),('zack','放',2),('zack','飞',1),('zack','分',2),('zack','枫',0),('zack','峰',0),('zack','风',1),('zack','佛',0),('zack','福',2),('zack','抚',1),('zack','该',0),('zack','盖',1),('zack','刚',1),('zack','高',0),('zack','告',1),('zack','哥',0),('zack','歌',0),('zack','鸽',0),('zack','个',2),('zack','各',1),('zack','给',1),('zack','根',1),('zack','跟',1),('zack','更',1),('zack','工',1),('zack','功',2),('zack','共',1),('zack','沟',0),('zack','狗',0),('zack','谷',0),('zack','瓜',1),('zack','挂',2),('zack','怪',2),('zack','光',2),('zack','龟',0),('zack','鬼',1),('zack','柜',0),('zack','锅',0),('zack','果',1),('zack','过',2),('zack','孩',2),('zack','海',0),('zack','好',2),('zack','喝',0),('zack','禾',0),('zack','和',1),('zack','合',1),('zack','盒',1),('zack','河',0),('zack','褐',0),('zack','黑',0),('zack','很',1),('zack','亨',2),('zack','轰',1),('zack','虹',0),('zack','红',2),('zack','后',2),('zack','忽',1),('zack','湖',0),('zack','虎',2),('zack','花',2),('zack','华',1),('zack','滑',0),('zack','画',0),('zack','化',0),('zack','话',1),('zack','怀',2),('zack','坏',1),('zack','欢',1),('zack','还',2),('zack','黄',2),('zack','灰',0),('zack','回',1),('zack','会',2),('zack','火',0),('zack','机',1),('zack','肌',0),('zack','鸡',0),('zack','几',1),('zack','家',1),('zack','加',1),('zack','甲',1),('zack','假',0),('zack','架',0),('zack','间',0),('zack','捡',2),('zack','减',0),('zack','见',2),('zack','姜',0),('zack','江',0),('zack','酱',0),('zack','椒',0),('zack','交',2),('zack','脚',1),('zack','叫',1),('zack','姐',0),('zack','今',1),('zack','进',1),('zack','近',0),('zack','茎',0),('zack','睛',2),('zack','晶',2),('zack','警',2),('zack','敬',2),('zack','九',2),('zack','酒',0),('zack','就',1),('zack','具',1),('zack','开',2),('zack','看',1),('zack','扛',0),('zack','颗',0),('zack','可',1),('zack','空',2),('zack','口',1),('zack','哭',1),('zack','苦',0),('zack','块',2),('zack','筷',0),('zack','快',2),('zack','拉',1),('zack','辣',0),('zack','来',1),('zack','蓝',0),('zack','劳',1),('zack','老',2),('zack','乐',2),('zack','雷',0),('zack','冷',0),('zack','梨',0),('zack','离',0),('zack','理',0),('zack','里',2),('zack','礼',0),('zack','丽',1),('zack','例',1),('zack','立',2),('zack','哩',2),('zack','凉',0),('zack','两',2),('zack','辆',1),('zack','亮',2),('zack','了',2),('zack','林',1),('zack','龄',1),('zack','岭',0),('zack','六',2),('zack','露',1),('zack','路',1),('zack','绿',2),('zack','妈',2),('zack','麻',0),('zack','马',2),('zack','吗',1),('zack','买',1),('zack','麦',0),('zack','卖',1),('zack','满',0),('zack','忙',1),('zack','毛',1),('zack','帽',0),('zack','么',2),('zack','没',2),('zack','眉',0),('zack','每',1),('zack','美',1),('zack','妹',0),('zack','们',1),('zack','米',1),('zack','面',1),('zack','民',2),('zack','明',2),('zack','墨',0),('zack','某',1),('zack','木',1),('zack','目',0),('zack','拿',2),('zack','哪',2),('zack','那',2),('zack','奶',0),('zack','南',2),('zack','男',0),('zack','能',1),('zack','你',2),('zack','年',1),('zack','鸟',2),('zack','牛',0),('zack','怒',0),('zack','女',0),('zack','暖',0),('zack','爬',0),('zack','怕',1),('zack','排',0),('zack','盘',0),('zack','旁',0),('zack','跑',2),('zack','盆',0),('zack','朋',2),('zack','皮',1),('zack','瓢',0),('zack','期',1),('zack','七',2),('zack','棋',0),('zack','奇',2),('zack','骑',1),('zack','起',1),('zack','器',1),('zack','气',1),('zack','千',2),('zack','钱',2),('zack','前',2),('zack','悄',0),('zack','琴',0),('zack','禽',0),('zack','清',0),('zack','请',1),('zack','秋',1),('zack','求',1),('zack','去',1),('zack','全',0),('zack','却',0),('zack','然',1),('zack','让',1),('zack','热',0),('zack','人',2),('zack','日',0),('zack','如',1),('zack','三',2),('zack','山',1),('zack','闪',2),('zack','上',2),('zack','少',1),('zack','蛇',0),('zack','舌',0),('zack','身',1),('zack','声',2),('zack','生',1),('zack','师',1),('zack','狮',0),('zack','十',2),('zack','石',0),('zack','时',1),('zack','什',2),('zack','史',0),('zack','世',2),('zack','是',2),('zack','手',2),('zack','兽',0),('zack','叔',2),('zack','书',2),('zack','薯',0),('zack','树',1),('zack','数',1),('zack','刷',0),('zack','水',1),('zack','睡',1),('zack','说',2),('zack','烁',0),('zack','死',1),('zack','四',2),('zack','松',1),('zack','诉',1),('zack','酸',0),('zack','蒜',0),('zack','虽',0),('zack','岁',1),('zack','他',2),('zack','它',1),('zack','抬',1),('zack','太',2),('zack','糖',0),('zack','桃',0),('zack','体',0),('zack','天',2),('zack','田',1),('zack','甜',0),('zack','挑',1),('zack','跳',0),('zack','听',0),('zack','同',1),('zack','投',2),('zack','头',2),('zack','土',1),('zack','推',0),('zack','洼',0),('zack','袜',0),('zack','外',1),('zack','玩',1),('zack','完',1),('zack','碗',0),('zack','晚',1),('zack','万',2),('zack','为',0),('zack','尾',2),('zack','位',1),('zack','温',0),('zack','文',0),('zack','问',1),('zack','窝',0),('zack','我',2),('zack','握',2),('zack','五',2),('zack','舞',0),('zack','西',2),('zack','习',2),('zack','喜',0),('zack','洗',0),('zack','细',0),('zack','虾',1),('zack','霞',0),('zack','下',2),('zack','夏',0),('zack','先',0),('zack','现',1),('zack','线',1),('zack','相',0),('zack','想',1),('zack','像',1),('zack','象',2),('zack','小',2),('zack','校',0),('zack','笑',2),('zack','鞋',0),('zack','挟',0),('zack','写',0),('zack','蟹',0),('zack','新',1),('zack','心',1),('zack','星',2),('zack','行',1),('zack','幸',2),('zack','熊',0),('zack','秀',0),('zack','需',1),('zack','许',2),('zack','学',2),('zack','鸦',0),('zack','鸭',0),('zack','呀',2),('zack','芽',1),('zack','牙',1),('zack','烟',0),('zack','盐',0),('zack','眼',2),('zack','燕',1),('zack','砚',0),('zack','焰',0),('zack','羊',0),('zack','阳',2),('zack','样',1),('zack','药',1),('zack','要',2),('zack','爷',0),('zack','野',0),('zack','也',1),('zack','叶',1),('zack','一',2),('zack','衣',1),('zack','椅',0),('zack','已',1),('zack','乙',1),('zack','以',1),('zack','鹰',0),('zack','迎',1),('zack','用',1),('zack','油',0),('zack','游',1),('zack','有',2),('zack','友',2),('zack','右',2),('zack','又',1),('zack','幼',0),('zack','于',1),('zack','鱼',1),('zack','雨',1),('zack','与',1),('zack','育',1),('zack','原',1),('zack','远',1),('zack','月',1),('zack','云',0),('zack','运',1),('zack','再',1),('zack','在',2),('zack','早',2),('zack','怎',1),('zack','炸',1),('zack','站',1),('zack','张',1),('zack','找',2),('zack','照',2),('zack','这',2),('zack','真',2),('zack','正',1),('zack','枝',1),('zack','知',0),('zack','之',1),('zack','直',1),('zack','只',2),('zack','纸',0),('zack','中',1),('zack','猪',0),('zack','竹',0),('zack','住',1),('zack','抓',0),('zack','装',1),('zack','桌',0),('zack','着',1),('zack','子',2),('zack','自',1),('zack','走',1),('zack','足',0),('zack','最',0),('zack','左',2),('zack','做',1),('zack','作',1),('zack','坐',1),('zack','座',1),('zack','桦',0),('zack','焐',1),('zack','鹂',2);
/*!40000 ALTER TABLE `userhzlvl` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-03  0:51:41
