-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: yz
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `wenzhang`
--

DROP TABLE IF EXISTS `wenzhang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wenzhang` (
  `idwenzhang` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(45) NOT NULL,
  `status` int(11) DEFAULT '0',
  PRIMARY KEY (`idwenzhang`),
  UNIQUE KEY `title_UNIQUE` (`title`),
  UNIQUE KEY `idwenzhang_UNIQUE` (`idwenzhang`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=gb2312;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wenzhang`
--

LOCK TABLES `wenzhang` WRITE;
/*!40000 ALTER TABLE `wenzhang` DISABLE KEYS */;
INSERT INTO `wenzhang` VALUES (1,'太阳当空照',2),(2,'春天在哪里',2),(5,'我在马路边',2),(6,'找朋友',2),(7,'一闪一闪亮晶晶',2),(8,'两只老虎',2),(9,'数字',2),(10,'方向',2),(11,'小燕子',1),(12,'小松树',1),(13,'世上只有妈妈好',2),(14,'看图识字',0),(16,'小燕子（二）',1),(17,'太阳当空照（二）',1),(18,'冬天里的一把火',0),(19,'故乡的云',0),(20,'我们的祖国是花园',0),(21,'我们的祖国是花园（二）',0),(22,'小鸭子',0),(23,'四季',0),(24,'我爱北京天安门',0);
/*!40000 ALTER TABLE `wenzhang` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-03  0:51:40
