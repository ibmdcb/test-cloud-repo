-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: yz
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hztogrp`
--

DROP TABLE IF EXISTS `hztogrp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hztogrp` (
  `hanzi` char(1) NOT NULL,
  `idgrp` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hztogrp`
--

LOCK TABLES `hztogrp` WRITE;
/*!40000 ALTER TABLE `hztogrp` DISABLE KEYS */;
INSERT INTO `hztogrp` VALUES ('不',6),('个',13),('交',9),('人',13),('从',13),('仿',14),('众',13),('刘',15),('化',18),('华',18),('吗',7),('吧',5),('哗',18),('坊',14),('坏',6),('块',16),('大',13),('天',13),('太',13),('妈',7),('妨',14),('尺',10),('尽',10),('工',8),('巴',5),('很',12),('快',16),('怀',6),('恨',12),('情',17),('房',14),('把',5),('放',14),('效',9),('文',15),('方',14),('日',11),('明',11),('晴',17),('晶',11),('校',9),('根',12),('桦',18),('清',17),('爸',5),('犬',13),('狠',12),('环',6),('痕',12),('眼',12),('睛',17),('空',8),('筷',16),('精',17),('红',8),('纹',15),('纺',14),('花',18),('芳',14),('蚂',7),('蚊',15),('蜻',17),('访',14),('请',17),('跟',12),('较',9),('还',6),('这',15),('迟',10),('防',14),('阳',11),('青',17),('马',7),('骂',7),('红',20),('黄',20),('橙',20),('绿',20),('青',20),('蓝',20),('紫',20),('红',21),('黄',21),('橙',21),('绿',21),('青',21),('蓝',21),('紫',21),('红',22),('黄',22),('橙',22),('绿',22),('青',22),('蓝',22),('紫',22);
/*!40000 ALTER TABLE `hztogrp` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-03  0:51:41
